﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DashBoardAula.Models
{
    public class Produto
    {
        public string nome { get; set; }

        public string valor { get; set; }
    }
}
